# ReelsGuard — Android app

A dark-mode Android Instagram Reels blocker with a main ON/OFF switch, daily blocked-attempt counter, 15-minute pause and Accessibility Settings shortcut.

## Easiest phone-only cloud build (GitHub Actions)

This method uploads just ONE ZIP file, then creates one workflow file on GitHub. You do not need Android Studio or a laptop.

### 1. Download the project
Download `ReelsGuard_Android_Project.zip` and keep it in Downloads. You do not need to extract it for this method.

### 2. Create a GitHub repository
1. Open https://github.com in Chrome and sign in or create a free account.
2. Tap `+` > **New repository**.
3. Name it `ReelsGuard`.
4. Choose **Public** for unlimited free standard GitHub-hosted Actions runner use. This makes the source ZIP public. Choose **Private** if you prefer privacy; private repositories use your plan's included compute/storage allowance.
5. Create the repository. Do not add a README, .gitignore or licence.

### 3. Upload the ZIP
1. In the new repository tap **Add file** > **Upload files**.
2. Select `ReelsGuard_Android_Project.zip` from Downloads.
3. Scroll down and tap **Commit changes**.

### 4. Create the build workflow
1. Return to the repository's **Code** tab.
2. Tap **Add file** > **Create new file**.
3. For the filename enter exactly: `.github/workflows/build-apk.yml`
4. Open `GITHUB_WORKFLOW_COPY.txt` from this project ZIP (extract it if needed), copy all its contents, and paste them into GitHub's editor.
5. Tap **Commit changes**.

The workflow file is also shown below for convenience:

```yaml
name: Build ReelsGuard APK
on:
  workflow_dispatch:
  push:
    branches: [ "main" ]
permissions:
  contents: read
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v6
      - uses: actions/setup-java@v6
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v6
        with:
          gradle-version: '8.9'
      - name: Extract project ZIP
        run: unzip -q ReelsGuard_Android_Project.zip
      - name: Build debug APK
        working-directory: ReelsGuard
        run: gradle --no-daemon assembleDebug
      - uses: actions/upload-artifact@v4
        with:
          name: ReelsGuard-debug-apk
          path: ReelsGuard/app/build/outputs/apk/debug/app-debug.apk
          if-no-files-found: error
          retention-days: 14
```

### 5. Start the build
1. Open the repository's **Actions** tab.
2. Select **Build ReelsGuard APK** on the left.
3. If prompted, enable GitHub Actions.
4. Tap **Run workflow**, select `main`, and tap the green **Run workflow** button.
5. Wait for a green check mark. If it fails, open the run and inspect the failed step/log.

### 6. Download and install
1. Open the successful workflow run.
2. Scroll to **Artifacts** and tap **ReelsGuard-debug-apk**.
3. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
4. Tap `app-debug.apk`; if Android asks, allow your browser or file manager to install unknown apps.
5. Install and open ReelsGuard.

## Enable the blocker
1. Open ReelsGuard and tap **ON**.
2. Tap **Open Accessibility Settings**.
3. Find ReelsGuard under installed/downloaded services and enable it.
4. Accept Android's accessibility warning and return to the app.
5. Check that the app says the Accessibility service is enabled, then test Instagram's Reels tab.

## Features
- ON/OFF protection switch; preference is saved.
- Daily count of detected Reels openings blocked (not total watch time).
- Voluntary 15-minute pause with resume button.
- Offline operation; no login or account data collection.
- Dark navy interface with green accent, rounded cards and a blocking screen.

## Limitations and safety
- Targets the regular Instagram Android app package `com.instagram.android`, not Instagram Lite.
- Reels detection is heuristic and uses visible accessibility labels, resource IDs and screen class names. Instagram UI changes can cause missed detections or occasional false positives.
- The service only inspects the visible accessibility tree locally to identify Instagram's screen; it does not send it to a server. Android's Accessibility permission is powerful, so enable it only if you trust the app source.
- The pause is voluntary, not tamper-proof. The app is a personal debug build, not a Play Store release.
- GitHub Actions standard runners are free for public repositories; private repository use is subject to the current account allowance and billing rules. See GitHub's official billing documentation.
