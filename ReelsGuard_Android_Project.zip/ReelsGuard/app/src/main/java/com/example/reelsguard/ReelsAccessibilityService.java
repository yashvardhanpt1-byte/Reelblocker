package com.example.reelsguard;
import android.accessibilityservice.AccessibilityService;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ReelsAccessibilityService extends AccessibilityService {
 WindowManager wm; android.view.View cover; boolean wasBlocked=false;
 int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
 @Override public void onServiceConnected(){super.onServiceConnected();wm=(WindowManager)getSystemService(WINDOW_SERVICE);}
 @Override public void onAccessibilityEvent(AccessibilityEvent e){
  if(e==null)return;SharedPreferences p=getSharedPreferences(MainActivity.PREFS,MODE_PRIVATE);
  boolean enabled=p.getBoolean(MainActivity.KEY_ENABLED,false),paused=p.getLong(MainActivity.KEY_PAUSE_UNTIL,0)>System.currentTimeMillis();
  if(!enabled||paused){wasBlocked=false;removeCover();return;}
  String pkg=e.getPackageName()==null?"":e.getPackageName().toString();
  if(getPackageName().equals(pkg)) return; // Ignore events from the blocker overlay itself.
  if(!"com.instagram.android".equals(pkg)){wasBlocked=false;removeCover();return;}
  AccessibilityNodeInfo root=getRootInActiveWindow();boolean reels=isReels(root,e);if(root!=null)root.recycle();
  if(reels){if(!wasBlocked)record(p);wasBlocked=true;showCover();}else{wasBlocked=false;removeCover();}
 }
 boolean isReels(AccessibilityNodeInfo root,AccessibilityEvent e){
  String cls=e.getClassName()==null?"":e.getClassName().toString().toLowerCase(Locale.ROOT);
  if(cls.contains("clipsviewer")||cls.contains("reelsviewer"))return true;
  StringBuilder b=new StringBuilder();boolean id=idSearch(root,b,0);if(id)return true;
  String s=b.toString().toLowerCase(Locale.ROOT);int controls=0;String[] keys={"like","comment","share","remix","audio","send"};for(String k:keys)if(s.contains(k))controls++;
  return (s.contains("reels")||s.contains("reel"))&&controls>=2 || (s.contains("original audio")||s.contains("audio"))&&controls>=4;
 }
 boolean idSearch(AccessibilityNodeInfo n,StringBuilder b,int depth){
  if(n==null||depth>32)return false;boolean hit=false;CharSequence t=n.getText(),d=n.getContentDescription();if(t!=null)b.append(' ').append(t);if(d!=null)b.append(' ').append(d);
  String id=n.getViewIdResourceName();if(id!=null){String x=id.toLowerCase(Locale.ROOT);b.append(' ').append(x);hit=x.contains("clips_viewer")||x.contains("reels_viewer")||x.contains("clipsviewer")||x.contains("reelsviewer");}
  for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null){hit|=idSearch(c,b,depth+1);c.recycle();}}return hit;
 }
 void record(SharedPreferences p){String day=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());String old=p.getString(MainActivity.KEY_BLOCK_DATE,"");int n=day.equals(old)?p.getInt(MainActivity.KEY_BLOCK_COUNT,0):0;p.edit().putString(MainActivity.KEY_BLOCK_DATE,day).putInt(MainActivity.KEY_BLOCK_COUNT,n+1).apply();}
 void showCover(){if(cover!=null||wm==null)return;int bg=0xff0a0e14,green=0xff5bdc9b;LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setGravity(Gravity.CENTER);box.setPadding(dp(32),dp(32),dp(32),dp(32));box.setBackgroundColor(bg);
  TextView mark=new TextView(this);mark.setText("R");mark.setTextColor(bg);mark.setTextSize(27);mark.setTypeface(Typeface.DEFAULT,1);mark.setGravity(Gravity.CENTER);GradientDrawable badge=new GradientDrawable();badge.setColor(green);badge.setCornerRadius(dp(22));mark.setBackground(badge);box.addView(mark,new LinearLayout.LayoutParams(dp(64),dp(64)));
  TextView title=new TextView(this);title.setText("Reels blocked.");title.setTextColor(Color.WHITE);title.setTextSize(28);title.setTypeface(Typeface.DEFAULT,1);title.setGravity(Gravity.CENTER);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=dp(24);box.addView(title,tp);
  TextView body=new TextView(this);body.setText("You came here for a reason. Take a breath and return to what matters.");body.setTextColor(0xffa5b2c0);body.setTextSize(15);body.setGravity(Gravity.CENTER);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.topMargin=dp(12);box.addView(body,bp);
  Button back=new Button(this);back.setText("GO BACK TO INSTAGRAM");back.setAllCaps(false);back.setTextColor(bg);back.setTextSize(12);back.setTypeface(Typeface.DEFAULT,1);GradientDrawable bd=new GradientDrawable();bd.setColor(green);bd.setCornerRadius(dp(16));back.setBackground(bd);back.setOnClickListener(v->{performGlobalAction(GLOBAL_ACTION_BACK);removeCover();wasBlocked=false;});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(54));lp.topMargin=dp(28);box.addView(back,lp);
  WindowManager.LayoutParams params=new WindowManager.LayoutParams(-1,-1,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);params.gravity=Gravity.TOP|Gravity.START;try{wm.addView(box,params);cover=box;}catch(Exception ex){cover=null;}
 }
 void removeCover(){if(cover!=null&&wm!=null){try{wm.removeView(cover);}catch(Exception ignored){}cover=null;}}
 @Override public void onInterrupt(){wasBlocked=false;removeCover();}
 @Override public void onDestroy(){removeCover();super.onDestroy();}
}
