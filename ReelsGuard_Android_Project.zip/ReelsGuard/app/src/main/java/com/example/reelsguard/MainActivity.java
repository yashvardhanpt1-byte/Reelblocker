package com.example.reelsguard;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
 static final String PREFS="reelsguard_settings", KEY_ENABLED="enabled", KEY_PAUSE_UNTIL="pause_until", KEY_BLOCK_COUNT="block_count", KEY_BLOCK_DATE="block_date";
 final int BG=0xff0a0e14, CARD=0xff161d27, WHITE=0xfff2f6fa, MUTED=0xff97a4b3, GREEN=0xff5bdc9b;
 SharedPreferences prefs; TextView status, toggle, count, service, pause;
 int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
 GradientDrawable shape(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
 TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
 LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(19),dp(18),dp(19),dp(18));l.setBackground(shape(CARD,20));return l;}
 void gap(LinearLayout p,int h){View v=new View(this);p.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
 @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences(PREFS,MODE_PRIVATE);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
  ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(BG);LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(22),dp(24),dp(22),dp(28));scroll.addView(root);
  LinearLayout brand=new LinearLayout(this);brand.setGravity(Gravity.CENTER_VERTICAL);TextView mark=txt("R",22,BG,true);mark.setGravity(Gravity.CENTER);mark.setBackground(shape(GREEN,16));brand.addView(mark,new LinearLayout.LayoutParams(dp(44),dp(44)));
  LinearLayout brandText=new LinearLayout(this);brandText.setOrientation(1);brandText.setPadding(dp(12),0,0,0);brandText.addView(txt("ReelsGuard",20,WHITE,true));brandText.addView(txt("MAKE YOUR SCROLL INTENTIONAL",9,MUTED,true));brand.addView(brandText);root.addView(brand);
  gap(root,30);root.addView(txt("Your attention.",29,WHITE,true));root.addView(txt("Your choice.",29,GREEN,true));gap(root,8);root.addView(txt("A little distance from endless Reels can make room for what matters.",14,MUTED,false));
  gap(root,24);LinearLayout c=card();LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);LinearLayout labels=new LinearLayout(this);labels.setOrientation(1);labels.addView(txt("Reels protection",18,WHITE,true));status=txt("Checking status…",12,MUTED,false);labels.addView(status);row.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
  toggle=txt("OFF",14,WHITE,true);toggle.setGravity(Gravity.CENTER);toggle.setBackground(shape(0xff424e5c,24));toggle.setOnClickListener(v->{prefs.edit().putBoolean(KEY_ENABLED,!prefs.getBoolean(KEY_ENABLED,false)).apply();refresh();});row.addView(toggle,new LinearLayout.LayoutParams(dp(76),dp(42)));c.addView(row);gap(c,16);View line=new View(this);line.setBackgroundColor(0xff303b48);c.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));gap(c,14);c.addView(txt("When ON, ReelsGuard covers the Instagram Reels viewer. Your regular feed, messages and profile are not intentionally blocked.",13,MUTED,false));root.addView(c);
  gap(root,15);LinearLayout stats=card();stats.addView(txt("TODAY'S DISTRACTIONS AVOIDED",10,MUTED,true));gap(stats,7);count=txt("0",34,WHITE,true);stats.addView(count);stats.addView(txt("Reels openings blocked on this device",12,MUTED,false));root.addView(stats);
  gap(root,15);LinearLayout pc=card();pc.addView(txt("Need a short break?",16,WHITE,true));gap(pc,5);pc.addView(txt("Temporarily pause protection for 15 minutes. It resumes automatically.",12,MUTED,false));gap(pc,12);pause=txt("PAUSE FOR 15 MIN",12,GREEN,true);pause.setGravity(Gravity.CENTER);pause.setPadding(dp(12),dp(13),dp(12),dp(13));pause.setBackground(shape(0xff1b242f,14));pause.setOnClickListener(v->{long until=prefs.getLong(KEY_PAUSE_UNTIL,0);prefs.edit().putLong(KEY_PAUSE_UNTIL,until>System.currentTimeMillis()?0:System.currentTimeMillis()+900000L).apply();refresh();});pc.addView(pause);root.addView(pc);
  gap(root,15);LinearLayout setup=card();setup.addView(txt("SETUP & PERMISSIONS",10,MUTED,true));gap(setup,9);service=txt("Accessibility service: not checked",13,WHITE,true);setup.addView(service);gap(setup,10);Button open=new Button(this);open.setText("Open Accessibility Settings");open.setAllCaps(false);open.setTextColor(BG);open.setBackground(shape(GREEN,14));open.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));setup.addView(open);root.addView(setup);
  gap(root,18);TextView foot=txt("PRIVATE BY DESIGN  •  NO LOGIN  •  NO ACCOUNT DATA",9,MUTED,true);foot.setGravity(Gravity.CENTER);root.addView(foot);gap(root,7);TextView note=txt("Detection depends on Instagram's accessibility labels and may need updates if Instagram changes its interface.",11,MUTED,false);note.setGravity(Gravity.CENTER);root.addView(note);setContentView(scroll);refresh();
 }
 boolean serviceEnabled(){AccessibilityManager am=(AccessibilityManager)getSystemService(ACCESSIBILITY_SERVICE);if(am==null)return false;String expected=getPackageName()+"/"+ReelsAccessibilityService.class.getName();for(android.accessibilityservice.AccessibilityServiceInfo i:am.getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK)){if(i.getResolveInfo()!=null&&i.getResolveInfo().serviceInfo!=null){String a=i.getResolveInfo().serviceInfo.packageName+"/"+i.getResolveInfo().serviceInfo.name;if(expected.equals(a))return true;}}return false;}
 void refresh(){if(status==null)return;boolean on=prefs.getBoolean(KEY_ENABLED,false);boolean paused=prefs.getLong(KEY_PAUSE_UNTIL,0)>System.currentTimeMillis();status.setText(paused?"Temporarily paused":on?"Protection is active":"Protection is switched off");status.setTextColor(paused?0xffffc669:on?GREEN:MUTED);toggle.setText(on?"ON":"OFF");toggle.setTextColor(on?BG:WHITE);toggle.setBackground(shape(on?GREEN:0xff424e5c,24));pause.setText(paused?"RESUME PROTECTION NOW":"PAUSE FOR 15 MIN");boolean active=serviceEnabled();service.setText(active?"Accessibility service: enabled":"Accessibility service: needs enabling");service.setTextColor(active?GREEN:0xffffc669);String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());count.setText(String.valueOf(today.equals(prefs.getString(KEY_BLOCK_DATE,""))?prefs.getInt(KEY_BLOCK_COUNT,0):0));}
 @Override protected void onResume(){super.onResume();if(prefs!=null)refresh();}
}
